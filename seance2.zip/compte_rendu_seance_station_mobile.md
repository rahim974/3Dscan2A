# Compte rendu de séance

## Dimensionnement de la portée de détection

Au cours de cette séance, nous avons commencé par chercher à estimer les limites de distance de notre système de perception en nous basant sur la caméra associée à la STM32N6570-DK et sur l’utilisation d’un modèle de détection de type YOLO.

L’objectif était de déterminer jusqu’à quelle distance des objets comme des tables, des chaises ou des personnes pouvaient rester suffisamment visibles dans l’image pour être détectés de manière fiable. Nous avons notamment pris en compte :

- le champ de vision de la caméra ;
- la résolution d’entrée du modèle YOLO ;
- la taille apparente des objets en fonction de la distance ;
- la diminution progressive de la fiabilité de détection lorsque les objets occupent moins de pixels dans l’image ;
- la portée propre du LiDAR, qui constitue une autre limite physique du système.

Ces estimations ont montré qu’une station entièrement fixe risquait d’être rapidement limitée par la portée de reconnaissance de la caméra et par celle du LiDAR, en particulier pour les objets de petite taille ou situés loin du point de mesure.

## Choix d’une station de captation mobile

À la suite de cette réflexion, nous avons choisi d’orienter le projet vers une **station de captation mobile**, regroupant notamment :

- le LiDAR ;
- la caméra ;
- les capteurs nécessaires à l’estimation du mouvement et de l’orientation ;
- le système de calcul embarqué.

L’idée est que la station puisse se déplacer dans la salle afin de se rapprocher des zones à analyser et de multiplier les points de vue.

Ce choix permet de ne plus dépendre uniquement de la portée maximale d’un capteur placé à un point fixe. Il permet également d’obtenir plusieurs acquisitions d’une même zone sous différents angles, ce qui devrait améliorer la reconstruction globale de la salle et la reconnaissance des objets.

## Difficultés introduites par la mobilité

Nous sommes cependant conscients que ce choix augmente nettement la difficulté algorithmique du projet.

Le déplacement de la station va introduire des erreurs supplémentaires liées à l’estimation de sa position et de son orientation. Il faudra donc gérer les mouvements du système, mesurer leur influence sur les acquisitions et mettre en place des méthodes de correction afin de replacer correctement chaque mesure dans un même repère.

La fusion des différentes acquisitions devient également plus complexe. Les images et les mesures LiDAR seront prises depuis des positions différentes, ce qui rend leur alignement plus sensible aux erreurs de mouvement, de synchronisation et de calibration.

La suite du projet devra donc traiter à la fois la reconstruction de l’environnement et la compensation des erreurs liées au déplacement de la station.


## Difficultés principales liées à la station mobile

### Synthèse

| Difficulté | Difficulté relative | Urgence |
|---|---|---|
| Estimation de la position et de l’orientation de la station | 🔴 ★★★★★ | **1 — Prioritaire** |
| Dérive cumulative de l’odométrie | 🔴 ★★★★★ | **2 — Prioritaire** |
| Synchronisation caméra / LiDAR / IMU / encodeurs | 🟠 ★★★★☆ | **3 — Élevée** |
| Fusion et alignement des scans successifs | 🔴 ★★★★★ | **4 — Élevée** |
| Erreurs liées au mouvement pendant l’acquisition | 🟠 ★★★★☆ | **5 — Élevée** |
| Calibration entre caméra, LiDAR, IMU et repère de la station | 🟠 ★★★★☆ | **6 — Importante** |
| Présence d’objets mobiles dans la scène | 🟡 ★★★☆☆ | **7 — Moyenne** |
| Fermeture de boucle / correction globale de trajectoire | 🟠 ★★★★☆ | **8 — Plus tardive** |
| Exécution temps réel et optimisation embarquée | 🟠 ★★★★☆ | **9 — Après validation algorithmique** |

### Solutions envisagées, par ordre d’urgence

1. **Estimation de la pose de la station**
   - Ajouter des **encodeurs de roues**.
   - Utiliser l’**IMU** pour compléter l’estimation de l’orientation.
   - Travailler principalement en 2D avec une pose `(x, y, θ)` afin de limiter la complexité.

2. **Dérive cumulative**
   - Corriger l’odométrie à l’aide du LiDAR.
   - Tester un alignement de scans de type **ICP / scan matching**.
   - Comparer la pose estimée par odométrie avant et après correction LiDAR.

3. **Synchronisation des capteurs**
   - Associer un **timestamp commun** à chaque mesure.
   - Enregistrer systématiquement : LiDAR, image, IMU, encodeurs et instant d’acquisition.
   - Prévoir dès le début une structure de données commune pour faciliter la fusion ultérieure.

4. **Fusion des scans successifs**
   - Développer et valider l’algorithme d’abord sur PC.
   - Utiliser les poses estimées pour replacer chaque nuage de points dans un même repère.
   - Introduire des **keyframes** afin d’éviter de fusionner inutilement toutes les acquisitions.

5. **Mouvement pendant l’acquisition**
   - Pour la première version, adopter une stratégie **Stop-and-Scan** :
     `déplacement → arrêt → acquisition → déplacement`.
   - Garder le scan continu comme axe d’amélioration ultérieur.
   - Cette stratégie permet de réduire fortement le flou, la distorsion LiDAR et les erreurs de synchronisation.

6. **Calibration multi-capteurs**
   - Calibrer les transformations entre les repères caméra, LiDAR, IMU et station.
   - Fixer rigidement les capteurs afin que ces transformations restent constantes.

7. **Objets mobiles**
   - Détecter les classes dynamiques, notamment les personnes, avec YOLO.
   - Éviter d’utiliser ces points comme références pour l’alignement des scans.
   - Favoriser les éléments statiques comme les murs ou le mobilier fixe.

8. **Fermeture de boucle**
   - Dans un premier temps, envisager des repères visuels connus ou des points de référence.
   - Par la suite, étudier une correction automatique lorsque la station revisite une zone déjà cartographiée.

9. **Optimisation embarquée**
   - Conserver les traitements lourds sur PC pendant la phase de validation.
   - Migrer progressivement vers le STM32N6570-DK une fois les méthodes validées.
   - Mesurer ensuite le coût en mémoire, temps de calcul et énergie avant d’optimiser.
