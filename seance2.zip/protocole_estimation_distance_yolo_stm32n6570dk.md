# Protocole d’ingénierie pour estimer la distance maximale d’analyse YOLO
## Projet STM32N6570-DK + caméra IMX335 + VL53L9CX

## 1. Objet du protocole

Ce protocole vise à déterminer expérimentalement plusieurs distances caractéristiques pour la détection d’objets par YOLO avec la caméra utilisée sur la STM32N6570-DK.

L’objectif n’est pas de chercher une unique « portée maximale caméra », mais de définir des distances d’usage utiles pour le dimensionnement du système :

- **distance très confortable** ;
- **distance confortable** ;
- **distance nominale** ;
- **distance limite exploitable** ;
- **distance maximale de détection occasionnelle**.

Ces distances doivent être déterminées **par classe d’objet**, car une table, une chaise et une personne n’occupent pas la même taille apparente dans l’image.

---

# 2. Définitions proposées

## 2.1 Distance très confortable

Distance à laquelle le système fonctionne avec une marge importante.

Critères recommandés :

- Recall ≥ 95 %
- Precision ≥ 95 %
- taux de faux négatifs ≤ 5 %
- stabilité élevée entre plusieurs conditions lumineuses
- très faible sensibilité à l’orientation de l’objet
- taille apparente suffisante dans l’entrée YOLO

Cette distance correspond à la zone où l’on peut considérer la détection comme robuste.

---

## 2.2 Distance confortable

Distance à laquelle le système reste fiable dans des conditions normales d’utilisation.

Critères recommandés :

- Recall ≥ 90 %
- Precision ≥ 90 %
- faible sensibilité à l’orientation
- faible sensibilité à des variations modérées de luminosité
- détection stable sur plusieurs acquisitions successives

Cette distance peut être retenue comme **distance de fonctionnement recommandée**.

---

## 2.3 Distance nominale

Distance maximale à laquelle le système satisfait le cahier des charges principal.

Exemple de critère :

- Recall ≥ 85 %
- Precision ≥ 85 %
- localisation suffisamment stable
- taux de détection acceptable sur les objets d’intérêt

La distance nominale doit être définie en fonction des besoins du projet, et non uniquement des performances maximales possibles.

---

## 2.4 Distance limite exploitable

Distance à laquelle la détection reste possible, mais devient sensible aux conditions.

Critères typiques :

- Recall compris entre 60 et 80 %
- apparition fréquente de faux négatifs
- dépendance forte à l’orientation
- dépendance à la lumière
- forte diminution de la taille apparente dans l’image

Cette distance ne doit pas être utilisée comme distance de conception principale.

---

## 2.5 Distance maximale de détection occasionnelle

Distance à laquelle YOLO peut encore détecter certains objets dans de bonnes conditions, mais sans garantie de répétabilité.

Cette valeur est indicative uniquement.

Elle ne doit pas être utilisée comme spécification fonctionnelle.

---

# 3. Hypothèses initiales à documenter

Avant de commencer, consigner précisément :

- caméra utilisée ;
- capteur : Sony IMX335 ;
- objectif utilisé ;
- champ de vision horizontal ;
- résolution native ;
- résolution d’entrée YOLO ;
- modèle YOLO ;
- version du modèle ;
- quantification utilisée ;
- dataset d’entraînement ;
- classes détectées ;
- firmware STM32 ;
- version de ST Edge AI ;
- fréquence d’inférence ;
- mode d’exposition ;
- mise au point de l’objectif.

Exemple :

```text
Carte : STM32N6570-DK
Caméra : B-CAMS-IMX / IMX335
Objectif : M12, 87° FOV
Modèle : YOLOv8n
Entrée : 320 × 320
Quantification : INT8
Classe testée : chaise
```

---

# 4. Classes d’objets à tester

Le protocole doit être effectué séparément pour chaque classe utile.

Minimum recommandé :

- chaise ;
- table ;
- personne ;
- armoire ;
- porte.

Il est recommandé de sélectionner au moins trois objets physiques différents par classe lorsque c’est possible.

Exemple :

```text
Chaise A
Chaise B
Chaise C
```

Cela évite de mesurer uniquement la capacité du réseau à reconnaître un objet spécifique.

---

# 5. Définition du banc d’essai

## 5.1 Géométrie

Installer la caméra sur un support fixe.

Placer l’objet test face à la caméra.

Tracer ou mesurer précisément plusieurs distances.

Exemple :

```text
1,0 m
1,5 m
2,0 m
2,5 m
3,0 m
3,5 m
4,0 m
4,5 m
5,0 m
5,5 m
6,0 m
```

Le pas peut être :

- 0,5 m dans la zone critique ;
- 1 m dans la zone de forte confiance.

---

## 5.2 Hauteur

La caméra doit être placée à une hauteur représentative du scanner final.

Exemple :

```text
hauteur caméra = 1,20 m
```

Cette hauteur doit rester constante pendant l’ensemble du test.

---

## 5.3 Orientation

Chaque objet doit être testé sous plusieurs orientations.

Exemple pour une chaise :

```text
0°   : face
30°
45°
60°
90°  : profil
```

Cela permet d’évaluer la sensibilité du réseau à l’angle de présentation.

---

# 6. Conditions d’éclairage

Au minimum trois conditions doivent être étudiées.

## Condition A — Bonne lumière

Salle fortement éclairée.

## Condition B — Lumière normale

Éclairage représentatif d’une salle de classe ou d’un bureau.

## Condition C — Faible lumière

Éclairage dégradé mais encore réaliste.

Optionnel :

- contre-jour ;
- source lumineuse latérale ;
- lumière artificielle colorée.

L’objectif est de vérifier si la « distance maximale » varie fortement avec l’éclairage.

---

# 7. Conditions de fond

Tester plusieurs arrière-plans.

Exemples :

- mur clair ;
- mur sombre ;
- environnement encombré ;
- plusieurs objets proches ;
- objet partiellement occulté.

Le fond peut fortement influencer la capacité de détection.

---

# 8. Répétitions

À chaque configuration, effectuer plusieurs acquisitions.

Recommandation :

```text
N = 30 images minimum
```

par combinaison :

```text
distance
× orientation
× éclairage
× objet
```

Pour une campagne plus robuste :

```text
N = 50 à 100 images
```

---

# 9. Données à enregistrer

Pour chaque image, enregistrer :

```text
timestamp
classe attendue
distance réelle
orientation objet
éclairage
objet testé
détection oui/non
confidence YOLO
bounding box
temps d’inférence
```

Optionnel :

```text
température carte
consommation
RAM utilisée
```

---

# 10. Métriques principales

## 10.1 Recall

```text
Recall = vrais positifs / objets réellement présents
```

Cette métrique est particulièrement importante pour un système de détection d’obstacles.

Un faux négatif est souvent plus problématique qu’un faux positif.

---

## 10.2 Precision

```text
Precision = vrais positifs / toutes les détections positives
```

Permet de mesurer le taux de fausses détections.

---

## 10.3 Confidence moyenne

Calculer :

```text
confidence moyenne
écart-type
confidence minimale
```

pour chaque distance.

---

## 10.4 Stabilité

Mesurer la répétabilité entre plusieurs images consécutives.

Exemple :

```text
30 images
28 détections correctes
```

donne :

```text
taux de stabilité = 93,3 %
```

---

# 11. Taille apparente de l’objet

Mesurer également la taille de la bounding box dans l’image YOLO.

Variables intéressantes :

```text
largeur en pixels
hauteur en pixels
surface en pixels²
```

Cette mesure permettra de relier les performances réelles à la théorie.

Exemple :

```text
chaise à 2 m : 45 px
chaise à 3 m : 31 px
chaise à 4 m : 22 px
```

---

# 12. Critère théorique basé sur la taille en pixels

Une estimation initiale peut être faite avec :

```text
p = N × W / [2 × D × tan(FOV/2)]
```

avec :

- `p` = taille apparente en pixels ;
- `N` = résolution horizontale YOLO ;
- `W` = dimension réelle de l’objet ;
- `D` = distance ;
- `FOV` = champ de vision horizontal.

On peut inverser :

```text
D = N × W / [2 × p × tan(FOV/2)]
```

Cette formule doit être utilisée uniquement comme estimation initiale.

Les résultats expérimentaux restent prioritaires.

---

# 13. Valeurs de seuil recommandées

Pour le dimensionnement initial, utiliser :

```text
≥ 40 px : très confortable
≥ 32 px : confortable
≥ 24 px : exploitable
15 à 24 px : limite
< 15 px : non recommandé
```

Ces seuils doivent être validés expérimentalement.

---

# 14. Matrice d’essai recommandée

Exemple pour une chaise :

| Distance | Orientation | Lumière | Nb images |
|---|---:|---|---:|
| 1,0 m | 0° | normale | 30 |
| 1,5 m | 0° | normale | 30 |
| 2,0 m | 0° | normale | 30 |
| 2,5 m | 0° | normale | 30 |
| 3,0 m | 0° | normale | 30 |
| 3,5 m | 0° | normale | 30 |
| 4,0 m | 0° | normale | 30 |
| 4,5 m | 0° | normale | 30 |
| 5,0 m | 0° | normale | 30 |

Puis répéter pour :

```text
45°
90°
```

et pour plusieurs niveaux de lumière.

---

# 15. Courbes à produire

## 15.1 Recall en fonction de la distance

```text
Recall
1.0 |──────────────
0.9 |───────────
0.8 |────────
0.7 |──────
0.6 |────
    +----------------
     1 2 3 4 5 6 m
```

---

## 15.2 Confidence en fonction de la distance

Permet de visualiser le moment où YOLO devient incertain.

---

## 15.3 Taille apparente en pixels en fonction de la distance

Permet de relier la théorie à la mesure.

---

## 15.4 Latence en fonction de la résolution

Comparer par exemple :

```text
256 × 256
320 × 320
416 × 416
```

---

# 16. Définition finale des distances

Une fois les courbes obtenues, appliquer des critères clairs.

Exemple :

## Très confortable

```text
Recall ≥ 95 %
Precision ≥ 95 %
```

dans toutes les orientations principales.

---

## Confortable

```text
Recall ≥ 90 %
Precision ≥ 90 %
```

dans les conditions nominales.

---

## Nominale

```text
Recall ≥ 85 %
Precision ≥ 85 %
```

avec conditions réalistes.

---

## Limite exploitable

```text
Recall ≥ 60 %
```

mais inférieur au seuil nominal.

---

## Maximum occasionnel

Dernière distance avec au moins une détection correcte répétée.

Ne pas utiliser comme spécification.

---

# 17. Critère de distance système

La distance utile du système complet doit être définie par la contrainte la plus forte.

Exemple :

```text
D_caméra_IA = 4,0 m
D_LiDAR = 8,8 m
```

alors :

```text
D_système = min(D_caméra_IA, D_LiDAR)
```

donc :

```text
D_système = 4,0 m
```

pour la reconnaissance sémantique.

Le LiDAR peut toujours mesurer au-delà, mais sans garantie d’identification de classe.

---

# 18. Cas particulier : classe limitante

Le dimensionnement final doit être basé sur la classe la plus difficile.

Exemple :

```text
table : 6 m
personne : 5 m
chaise : 3,5 m
```

Si la chaise est une classe obligatoire, alors :

```text
distance nominale système = 3,5 m
```

même si les tables sont reconnues plus loin.

---

# 19. Comparaison de modèles

Le même protocole doit être utilisé pour comparer :

- YOLOv8n 256 ;
- YOLOv8n 320 ;
- YOLOv8n 416 ;
- YOLOv8n-seg ;
- autre modèle candidat.

La comparaison doit se faire sur :

```text
distance confortable
distance nominale
distance limite
RAM
Flash
latence
énergie
```

---

# 20. Critère énergétique

Mesurer l’énergie par acquisition ou par scan.

```text
E = ∫ P(t) dt
```

Comparer par exemple :

```text
YOLO320
vs
YOLO416
```

Il est possible qu’un modèle plus lourd augmente la portée mais dégrade fortement l’efficacité énergétique.

---

# 21. Décision d’ingénierie

La configuration finale ne doit pas être choisie sur la distance maximale seule.

Critère recommandé :

```text
performance
--------------------------
latence + mémoire + énergie
```

Une configuration peut être retenue si elle apporte suffisamment de portée pour un coût acceptable.

---

# 22. Exemple de règle de décision

Exemple :

```text
YOLO320
distance confortable : 3,0 m
latence : 30 ms

YOLO416
distance confortable : 3,8 m
latence : 55 ms
```

Le gain de portée est :

```text
+0,8 m
```

pour une augmentation importante de latence.

La décision doit être prise en fonction du cahier des charges.

---

# 23. Résultat attendu du protocole

À la fin de la campagne d’essai, produire un tableau du type :

| Classe | Très confortable | Confortable | Nominale | Limite |
|---|---:|---:|---:|---:|
| Chaise | 2,0 m | 3,0 m | 3,5 m | 4,5 m |
| Table | 4,0 m | 5,5 m | 6,5 m | 8,0 m |
| Personne | 3,5 m | 5,0 m | 6,0 m | 7,0 m |

Ces valeurs sont à mesurer réellement.

---

# 24. Recommandation de protocole minimal

Pour une première campagne :

```text
1 modèle
1 résolution
3 classes
5 distances
3 orientations
2 conditions lumineuses
30 images par configuration
```

Nombre d’images :

```text
3 × 5 × 3 × 2 × 30 = 2700 images
```

C’est une campagne suffisamment sérieuse pour produire une première estimation fiable.

---

# 25. Recommandation de protocole complet

Pour une étude plus robuste :

```text
3 modèles
3 résolutions
5 classes
10 distances
3 orientations
3 éclairages
3 objets par classe
30 images
```

Cela représente un volume beaucoup plus important.

Il est préférable de procéder progressivement.

---

# 26. Go / No-Go

Définir des critères avant les essais.

Exemple :

```text
GO :
Recall ≥ 90 % à 3 m sur chaise

NO-GO :
Recall < 80 % à 3 m
```

Si le critère n’est pas atteint, tester :

```text
fine-tuning
résolution supérieure
objectif plus étroit
meilleur éclairage
dataset enrichi
```

---

# 27. Conclusion

La distance utile d’un système YOLO embarqué ne doit pas être définie comme une simple portée optique.

Elle doit être mesurée à partir de :

- la taille apparente des objets ;
- le recall ;
- la precision ;
- la stabilité ;
- l’éclairage ;
- l’orientation ;
- la résolution du réseau ;
- la classe de l’objet ;
- la latence ;
- la consommation énergétique.

La distance finale de conception doit correspondre à la **distance confortable ou nominale de la classe la plus contraignante**, et non à la meilleure distance observée dans des conditions idéales.
